import {extension as chrome,watchProgress} from './webextension.js';
import {allRecords} from './db.js';
import {initializeExternalLinks} from './external-links.js';
import {initTheme} from './theme.js';
import {ordinal,yearLabel,enrollmentPeriod,balance,money,GRADING,RATINGS,filtered,DAYS,available,conflicts,slotWarnings,occurrences,enrichCourseOfferings} from './core.js';
import {esc,icon,pages,navigation,footer,table,pairs,empty,recordStatus,selector,schedule,toast,openModal,closeModal,offeringRows,curriculumTable,assessmentCoursesTable,gradesResult,calendarEventDialog,sectionPicker,enrollmentReminders,confirmUnavailable,closeTransientDialogs,confirmCourseRemoval,pageHeading,calendarToolbar,courseInformation,COURSE_INFORMATION_SUBTITLE} from './ui.js';
import {calendarEvents} from './ics.js';
import {cachedFeed,requestFeedAccess,refreshFeed} from './canvas.js';
import {demoRecords,demoFeed} from './demo.js';
import {headerMinimized} from './navigation.js';
import {collectionReport} from './cache-report.js';
import {sidebarFrames} from './motion.js';
import {displayedProgress,syncProgress} from './progress-layout.js';
import {syncTablePeeks} from './table-layout.js';
import {syncSchedules} from './schedule-layout.js';
import {syncCalendarTitles} from './calendar-layout.js';
import {selectionsAfterNavigation} from './view-state.js';
import {openSettings} from './settings.js';
import {listenForDataReset} from './data-reset.js';
import {initializeFonts} from './fonts.js';
import {bindSectionPicker,cleanupSectionPickers} from './section-picker.js';
addEventListener('better-solar-fonts',()=>{syncSchedules();syncCalendarTitles();syncTablePeeks();});
const root=document.querySelector('#root');
let cacheDismissed=localStorage.getItem('betterSolarHideCacheReport')==='true';
function dismissCache(value){cacheDismissed=value;localStorage.setItem('betterSolarHideCacheReport',String(value));}
let minimized=false,scrollFrame=0,dataEpoch=0,cacheExpanded=false,creatorTransition=false,creatorMotion=false;
function updateHeader(){minimized=headerMinimized(scrollY,minimized);document.querySelector('#nav')?.classList.toggle('minimized',minimized);}
let records=[],feed,progress={},route='dashboard',demo=false,selected={},creatorOpen=false,creator=[],offerFilter={q:'',section:'',days:[]},viewDate=new Date(),calendarItems=[];
const isExtension=!!chrome?.runtime?.id;
const categoryFor={'balance-summary':'Account Balance Summary',saf:'Assessment',grades:'Grades','course-list':'Course Offerings'};
const rec=c=>records.find(r=>r.category===c),recs=c=>records.filter(r=>r.category===c).sort((a,b)=>b.year.localeCompare(a.year)||+b.term-+a.term);
const target=()=>{const s=selected[route];return s?records.find(r=>r.category===categoryFor[route]&&r.term===s.term&&r.year===s.year):null;};
function routeFromHash(){const value=location.hash.slice(1).split('?')[0];return pages[value]?value:'dashboard';}
function stateLine(){return `${cacheDismissed?'':collectionReport(records,progress,{expanded:cacheExpanded,demo,online:navigator.onLine,dismissible:true})}${!records.length&&progress.state!=='running'?'<p><button data-action="demo">Explore demo</button></p>':''}${demo?'<p><button data-action="leave-demo">Leave demo</button></p>':''}`;}

function heading(){return pageHeading(route,{firstName:rec('User Profile')?.data?.values?.['First Name']||'',collecting:progress.state==='running',hasData:!demo&&records.some(record=>record.data)});}
function profilePage(){const r=rec('User Profile');if(!r?.data)return recordStatus(r)+empty();const v=r.data.values,p=enrollmentPeriod(r.data.enrollmentHeading),student=['Student Number','First Name','Middle Name','Last Name','Personal Email Address','School Email Address','Citizenship','Program','Curriculum'];const y=v['Year Level'],n=y?.match(/\d+/)?.[0];return `<div class="grid-two"><section class="card"><h2 class="section-title"><span>${icon('book')}</span>Student Information</h2>${pairs(student.map(k=>[k,v[k==='Curriculum'?'Curriculum Code':k]]))}</section><section class="card"><h2 class="section-title"><span>${icon('check')}</span>Enrollment Status</h2>${pairs([['Current Term',p.term?ordinal(+p.term)+' term':''],['Current School Year',p.year?'SY '+yearLabel(p.year):''],['Year Level',n?ordinal(+n)+' Year':y],...['Registration Status','Student Type','Scholarship'].map(k=>[k,v[k]])])}</section></div>${recordStatus(r)}`;}
function groupLabel(h){const nums={first:1,second:2,third:3,fourth:4,fifth:5,sixth:6};const y=h.match(/(first|second|third|fourth|fifth|sixth|\d+(?:st|nd|rd|th)?)\s*year/i),t=h.match(/(\d+)(?:st|nd|rd|th)?\s*term/i);return y&&t?`${ordinal(nums[y[1].toLowerCase()]||parseInt(y[1]))} year - ${ordinal(+t[1])} Term`:h;}
function curriculumPage(){const r=rec('Curriculum');return r?.data?`<section class="card">${r.data.groups.map(g=>`<section class="curriculum-group"><h2>${esc(groupLabel(g.heading))}</h2>${curriculumTable(g.courses)}</section>`).join('')||empty('The source returned an empty curriculum.')}</section>${recordStatus(r)}`:recordStatus(r)+empty();}
function selectIntro(){const list=recs(categoryFor[route]);return selector(list)+(!list.length?empty('No term choices collected.','Scrape Data discovers the options available on each SOLAR page.'):!target()?`<section class="card selection-placeholder">${empty('Choose a term and school year.','Submit your selection to view its cached records.')}</section>`:'');}
function balancePage(){const r=target();if(!r)return '';if(!r.data)return recordStatus(r)+empty('This term could not be collected.','Use Retry failed work after signing in to SOLAR.');const d=r.data,b=balance(d.rawBalance);return `<section class="card"><p class="eyebrow">TERM ${esc(r.term)} · SY ${esc(yearLabel(r.year))}</p><h2>Account Balance Summary</h2>${pairs(['Full Name','Student Number','Statement of Account','Program Code','Beginning Balance','Total Assessment'].map(k=>[k,['Beginning Balance','Total Assessment'].includes(k)?money(d.values[k]):d.values[k],k==='Total Assessment']))}<hr><h2>Payment Summary</h2>${d.payments.length?d.payments.map((p,i)=>`<section aria-label="Payment ${i+1}">${pairs([['Amount Paid',money(p.paid)],['OR Number',p.or],['Date',p.date],['Mode',p.mode]])}${i<d.payments.length-1?'<hr>':''}</section>`).join(''):'<p class="muted">No payment records for this term.</p>'}<hr>${pairs([['Remaining Balance',b.remaining===null?'None':money(b.remaining)],['Overpayment',b.overpayment===null?'None':money(b.overpayment)]])}</section>${recordStatus(r)}`;}
function safPage(){const r=target();if(!r)return '';if(!r.data)return recordStatus(r)+empty('This term could not be collected.');const d=r.data;const payment=f=>/^(down payment|midterm|final|add\s*on)/i.test(f.label),fees=d.fees.filter(f=>!payment(f)),payments=d.fees.filter(payment);return `<div class="saf-grid"><section class="card"><p class="eyebrow">TERM ${esc(r.term)} · SY ${esc(yearLabel(r.year))}</p><h2>${d.summary['Enrollment Status']==='ENROLLED'?'Enrollment Summary':'Registration Summary'}</h2>${pairs(['Name','Student Number','Enrollment Status','Classification'].map(k=>[k,d.summary[k]]))}<hr>${assessmentCoursesTable(d.courses)}<hr><h2>Assessment details</h2>${pairs([['Total Credit Units',d.courses.reduce((sum,c)=>sum+(Number(c.credits)||0),0)],...fees.map(f=>[f.label,money(f.value),/total assessment/i.test(f.label)])])}<hr><h3>Payment Options</h3>${pairs(payments.map(f=>[f.label,money(f.value)]))}</section><section class="card">${schedule(d.courses,{source:'saf'})}</section></div>${recordStatus(r)}`;}
function grading(){return `<section class="card"><h2>Undergraduate Grading System</h2>${table(['Raw Score','Grade Point','Letter Rating','Percentage','Description'],GRADING.map(r=>r.map(esc)))}<div class="ratings"><h3>Other Ratings</h3>${RATINGS.map(([n,d])=>`<div class="rating-line"><span>${n}</span><span>-</span><span>${d}</span></div>`).join('')}</div></section>`;}
function gradesPage(){return `<div class="grades-stack">${gradesResult(target())}${grading()}</div>`;}

function offerCourses(){return enrichCourseOfferings(target()?.data?.courses||[],rec('Curriculum')?.data?.groups||[]);}

function filtersHTML(prefix,state,courses){return `<div class="filters" id="${prefix}-filters"><label>Course<input name="q" data-filter="${prefix}" placeholder="Search code or course title" value="${esc(state.q)}"></label>${sectionPicker(prefix,state.section)}<div class="day-filter"><span class="day-filter-label">Day</span><div class="filter-days" role="group" aria-label="Filter by day">${DAYS.map(day=>`<button type="button" data-day="${day}" data-prefix="${prefix}" aria-pressed="${state.days.includes(day)}">${day}</button>`).join('')}</div></div></div>`;}


function creatorHTML(){return `<div class="creator-heading"><button data-action="creator">Close Schedule Visualizer ${icon('close')}</button></div><div class="schedule-actions"><button data-action="add-course">Add an Individual Course</button><button data-action="add-block">Add a Block Section</button></div><div id="creator-week">${schedule(creator,{removable:true,highlightSlots:true,title:'Your schedule',source:'creator'})}</div>`;}
function coursesPage(){const r=target();if(!r)return '';if(!r.data)return recordStatus(r)+empty('This term could not be collected.');const courses=offerCourses();return `<div class="offerings-toolbar"><h2>Courses Offered for Term ${esc(r.term)}, SY ${esc(yearLabel(r.year))}</h2>${creatorOpen?'':`<button data-action="creator">Open Schedule Creator ${icon('calendar')}</button>`}</div><div class="${creatorOpen?'visualizer-grid':''}"><section class="card">${filtersHTML('main',offerFilter,courses)}<div id="offer-table">${offeringRows(filtered(courses,offerFilter))}</div><p class="record-status" id="filter-count">${filtered(courses,offerFilter).length} of ${courses.length} course rows</p></section>${creatorOpen?`<section class="card ${creatorMotion?'creator-enter':''}" id="creator-panel" tabindex="-1">${creatorHTML()}</section>`:''}</div>${recordStatus(r)}`;}
function calendarHTML(){const y=viewDate.getFullYear(),m=viewDate.getMonth(),first=new Date(y,m,1),start=new Date(y,m,1-first.getDay()),end=new Date(start);end.setDate(end.getDate()+42);let calendarError='';try{calendarItems=feed?.source?calendarEvents(feed.source,start,end):[];}catch(e){calendarError=e.message;calendarItems=[];}const month=viewDate.toLocaleDateString(undefined,{month:'long',year:'numeric'});const now=new Date();let cells='';for(let i=0;i<42;i++){const d=new Date(start);d.setDate(d.getDate()+i);const items=calendarItems.filter(e=>{const s=new Date(e.start),end=new Date(e.end);return s<new Date(d.getFullYear(),d.getMonth(),d.getDate()+1)&&end>d;}),today=d.toDateString()===now.toDateString();cells+=`<div class="calendar-cell ${d.getDay()===0||d.getDay()===6?'weekend ':''}${d.getMonth()!==m?'outside ':''}${today?'today':''}"><time class="calendar-date" datetime="${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}" ${today?'aria-current="date"':''}>${d.getDate()}</time>${items.map(e=>`<button class="calendar-event" data-event="${esc(e.id)}" aria-label="${esc(e.title)}"><span class="event-title" data-full-title="${esc(e.title)}">${esc(e.title)}</span></button>`).join('')}</div>`;}
 return `${calendarToolbar(month,{connected:!!feed?.url})}${calendarError?`<p class="notice warning">${esc(calendarError)}</p>`:''}<div class="calendar-weekdays">${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=>`<span>${d}</span>`).join('')}</div><div class="calendar-grid">${cells}</div><div class="calendar-caption"><span><i class="legend-dot" aria-hidden="true"></i>${calendarItems.length?`${calendarItems.length} activities in view`:feed?'No activities in this view':'Connect Canvas to see your upcoming activities'}</span>${feed?.fetchedAt?`<span>Cached ${esc(new Date(feed.fetchedAt).toLocaleDateString())}</span>`:''}</div>`;}
function activeAssessment(){const period=enrollmentPeriod(rec('User Profile')?.data?.enrollmentHeading||''),list=recs('Assessment').filter(record=>record.data);return list.find(record=>record.term===period.term&&record.year===period.year)||list[0];}
function dashboard(){const active=activeAssessment();return `<div class="dashboard-grid"><section class="card" id="calendar">${calendarHTML()}</section><section class="card">${active?`<p class="eyebrow">TERM ${esc(active.term)} · SY ${esc(yearLabel(active.year))}</p>`:''}${schedule(active?.data?.courses||[],{source:'dashboard'})}${active?recordStatus(active):'<p class="record-status">Collect Schedule and Assessment records to populate your timetable.</p>'}</section></div>`;}

function render({motion='none'}={}){const previousProgress=displayedProgress();cancelMenuMotion();const next=routeFromHash(),leaving=route!==next;cacheExpanded=leaving?false:(document.querySelector('.cache-bar details')?.open??cacheExpanded);selected=selectionsAfterNavigation(selected,route,next);if(leaving&&route==='course-list'){creator=[];creatorOpen=false;offerFilter={q:'',section:'',days:[]};sessionStorage.removeItem('creator');}route=next;let content;if(route==='dashboard')content=dashboard();else if(route==='user-profile')content=profilePage();else if(route==='curriculum')content=curriculumPage();else if(route==='enrollment-reminders')content=enrollmentReminders(rec('Enrollment Reminders'));else content=selectIntro()+({'balance-summary':balancePage,saf:safPage,grades:gradesPage,'course-list':coursesPage}[route])();root.innerHTML=navigation(route)+`<main id="main" class="app-main ${motion==='launch'?'launch-enter':motion==='page'?'page-enter':''}">${heading()}${demo?'<div class="notice warning"><strong>Demonstration mode.</strong> Every displayed academic record is synthetic. Leave demo to return to your own cached records.</div>':''}${stateLine()}${content}</main>`+footer();document.title=`${pages[route]} · Better SOLAR`;updateHeader();restoreMenu();syncProgress(previousProgress);cleanupSectionPickers();syncSchedules();syncCalendarTitles();syncTablePeeks();creatorMotion=false;if(categoryFor[route])bindTermForm();if(route==='course-list'&&target()?.data)bindFilters('main',offerFilter,offerCourses(),()=>updateOffers());}
function bindTermForm(){const form=document.querySelector('#term-form'),list=recs(categoryFor[route]),s=selected[route];if(s){form.elements.term.value=s.term;form.elements.year.value=s.year;}const validateOptions=()=>{const t=form.elements.term.value;[...form.elements.year.options].forEach(o=>{if(o.value)o.disabled=!!t&&!list.some(r=>r.term===t&&r.year===o.value);});if(form.elements.year.selectedOptions[0]?.disabled)form.elements.year.value='';};form.elements.term.onchange=validateOptions;validateOptions();form.onsubmit=e=>{e.preventDefault();const term=form.elements.term.value,year=form.elements.year.value;if(!list.some(r=>r.term===term&&r.year===year)){toast('This term/year combination has not been collected.');return;}const changed=selected[route]?.term!==term||selected[route]?.year!==year;selected[route]={term,year};if(route==='course-list'&&changed){creator=[];offerFilter={q:'',section:'',days:[]};persistCreator();}render();};}
function bindFilters(prefix,state,courses,onChange){
 const element=document.querySelector(`#${prefix}-filters`);if(!element)return;
 const search=element.querySelector('input[name=q]');search.oninput=()=>{state.q=search.value;onChange();};
 bindSectionPicker(element.querySelector('[data-section-picker]'),courses.map(course=>course.section),state.section,value=>{state.section=value;onChange();});
 element.querySelectorAll('[data-day]').forEach(button=>button.onclick=()=>{const day=button.dataset.day;state.days=state.days.includes(day)?state.days.filter(value=>value!==day):[...state.days,day];button.setAttribute('aria-pressed',String(state.days.includes(day)));onChange();});
}

function updateOffers(){const cs=offerCourses(),f=filtered(cs,offerFilter);document.querySelector('#offer-table').innerHTML=offeringRows(f);document.querySelector('#filter-count').textContent=`${f.length} of ${cs.length} course rows`;syncTablePeeks();}
function persistCreator(){const s=selected['course-list'];try{sessionStorage.setItem('creator',JSON.stringify({creator,selection:s,open:creatorOpen,demo}));}catch{toast('Schedule changes could not be retained for this window.');}}
async function showCourseInformation(block){
 if(!block.isConnected)return;const source=block.closest('.week-grid')?.dataset.scheduleSource;
 const courses=source==='creator'?creator:source==='saf'?target()?.data?.courses:source==='dashboard'?activeAssessment()?.data?.courses:null;
 const course=courses?.[Number(block.dataset.courseIndex)];if(!course)return;const meeting=occurrences(course).items[Number(block.dataset.meetingIndex)];
 if(source!=='creator'){openModal('Course information',courseInformation(course,meeting),undefined,{subtitle:COURSE_INFORMATION_SUBTITLE,footer:'<button data-close>Close</button>'});return;}
 const epoch=dataEpoch,record=target()?.id,choice=await confirmCourseRemoval(course,{meeting});if(!choice)return;
 if(epoch!==dataEpoch||record!==target()?.id||route!=='course-list')return;
 creator=choice==='all'?[]:creator.filter(item=>item._id!==course._id);refreshCreator();document.querySelector('#creator-panel')?.focus({preventScroll:true});toast(choice==='all'?'All courses removed from your schedule.':`${course.code} removed from your schedule.`);
}

function refreshCreator(){const p=document.querySelector('#creator-panel');if(p){p.innerHTML=creatorHTML();syncSchedules(p);}persistCreator();}
function addError(d,errors){const element=d.querySelector('.modal-error');if(element)element.textContent=errors.join('\n');syncTablePeeks(d);}
async function addToVisualizer(added,dialog,context,message){
 if(!added.length){addError(dialog,['Select at least one course.']);return;}
 const errors=conflicts(creator,added,{allowOverlap:true});if(errors.length){addError(dialog,errors);return;}
 if(slotWarnings(added).length&&!await confirmUnavailable(added))return;
 if(context.epoch!==dataEpoch||context.record!==target()?.id||route!=='course-list'||!dialog.open)return;
 creator.push(...added);await closeModal();if(context.epoch!==dataEpoch)return;refreshCreator();toast(message);
}
function addCoursesModal(){const context={epoch:dataEpoch,record:target()?.id},courses=offerCourses(),filter={q:'',section:'',days:[]},picked=new Set();openModal('Add an Individual Course',`<p class="muted picker-intro">Choose courses, then add them together. Courses with no remaining slots can be previewed after a warning and will appear red.</p>${filtersHTML('modal',filter,courses)}<div id="modal-offers"></div><div class="modal-error" role="alert"></div><div class="modal-actions"><span id="picked-count" role="status" aria-live="polite">0 selected</span><button data-close>Cancel</button><button class="primary" id="add-courses">Add Courses</button></div>`,d=>{d.classList.add('course-picker');
 const draw=()=>{const visible=filtered(courses,filter);const box=d.querySelector('#modal-offers');box.innerHTML=offeringRows(visible,{select:true,picked});[...box.querySelectorAll('tbody tr')].forEach((tr,i)=>{const c=visible[i];if(!c)return;const input=tr.querySelector('input');tr.classList.toggle('unavailable',!available(c));tr.classList.toggle('selected',picked.has(c._id));tr.style.cursor='pointer';tr.onclick=e=>{if(e.target!==input)input.checked=!input.checked;if(input.checked)picked.add(c._id);else picked.delete(c._id);tr.classList.toggle('selected',input.checked);d.querySelector('#picked-count').textContent=`${picked.size} selected`;};});syncTablePeeks(d);};draw();bindFilters('modal',filter,courses,draw);
 d.querySelector('#add-courses').onclick=async()=>{const added=courses.filter(course=>picked.has(course._id));await addToVisualizer(added,d,context,`${added.length} courses added to your schedule.`);};});}

function addBlockModal(){const context={epoch:dataEpoch,record:target()?.id},courses=offerCourses(),sections=[...new Set(courses.map(course=>course.section))].sort();
 openModal('Add a Block Section',`<p class="muted">Add every course in one section. The entire block is checked before anything is added.</p><form id="block-form"><div class="modal-field">${sectionPicker('block','',{placeholder:'Select a block section',allowAll:false,required:true})}</div><div class="modal-error" role="alert"></div><div class="modal-actions"><button type="button" data-close>Cancel</button><button class="primary" type="submit">Submit</button></div></form>`,dialog=>{
   bindSectionPicker(dialog.querySelector('[data-section-picker]'),sections,'',()=>{});
   dialog.querySelector('form').onsubmit=async event=>{event.preventDefault();const added=courses.filter(course=>course.section===event.currentTarget.elements.section.value);await addToVisualizer(added,dialog,context,'Block section added.');};
 });
}

function connectModal(){openModal('Connect to Canvas',`<p>In Canvas, open <strong>Calendar → Calendar Feed</strong> at the bottom-right of the page. Copy the feed URL and paste it below.</p><p class="muted">The private feed URL stays on this device. Your calendar is fetched directly from your Canvas instance and cached for offline viewing.</p><form id="canvas-form"><label class="modal-field">Canvas Calendar Feed URL<input name="feed" type="text" autocomplete="off" spellcheck="false" required placeholder="https://feu.instructure.com/feeds/calendars/… .ics" value="${esc(demo?'':feed?.url||'')}"></label><div class="modal-error" role="alert"></div><div class="modal-actions"><button type="button" data-close>Cancel</button><button type="submit" class="primary">${feed?.url?'Refresh Calendar':'Connect Calendar'}</button></div></form>`,d=>{d.querySelector('form').onsubmit=async e=>{e.preventDefault();const button=d.querySelector('[type=submit]');try{if(demo)throw Error('Leave demonstration mode before connecting a real Canvas account.');const request=requestFeedAccess(e.currentTarget.elements.feed.value);button.disabled=true;button.textContent='Connecting…';const url=await request;feed=await refreshFeed(url);closeModal();updateCalendar();toast('Canvas calendar saved for offline viewing.');}catch(error){addError(d,[error.message.includes('fetch')?'Canvas could not be reached. Check the feed URL and your connection, then retry.':error.message]);}finally{button.disabled=false;button.textContent='Connect Calendar';}};});}
async function send(type){if(!isExtension){toast('Install the extension to collect records from your signed-in SOLAR session.');return;}const r=await chrome.runtime.sendMessage({type});if(!r?.ok)throw Error(r?.error||'The extension did not respond. Reload it and retry.');return r;}
let menuOpen=false,menuAnimations=[],menuToken=0;
function cancelMenuMotion(){menuToken++;for(const animation of menuAnimations)animation.cancel();menuAnimations=[];}
function restoreMenu(){
 const panel=document.querySelector('#side-menu'),shade=document.querySelector('#menu-shade');
 if(!panel)return;panel.hidden=shade.hidden=!menuOpen;
 document.querySelectorAll('[data-action="menu"]').forEach(button=>button.setAttribute('aria-expanded',String(menuOpen)));
 document.body.style.overflow=menuOpen?'hidden':'';
}
async function setMenu(open){
 cancelMenuMotion();const token=menuToken;menuOpen=open;
 const panel=document.querySelector('#side-menu'),shade=document.querySelector('#menu-shade');if(!panel)return;
 panel.hidden=shade.hidden=false;document.body.style.overflow='hidden';
 document.querySelectorAll('[data-action="menu"]').forEach(button=>button.setAttribute('aria-expanded',String(open)));
 if(open)panel.querySelector('[data-action="menu-close"]').focus();
 if(!matchMedia('(prefers-reduced-motion: reduce)').matches&&typeof panel.animate==='function'){
   const timing={duration:220,easing:open?'cubic-bezier(.2,.7,.3,1)':'ease-in',fill:'forwards'};
   menuAnimations=[panel.animate(sidebarFrames(open),timing),shade.animate(open?[{opacity:0},{opacity:1}]:[{opacity:1},{opacity:0}],timing)];
   await Promise.allSettled(menuAnimations.map(animation=>animation.finished));
 }
 if(token!==menuToken)return;
 for(const animation of menuAnimations)animation.cancel();menuAnimations=[];restoreMenu();
 if(!open)document.querySelector('[data-action="menu"]')?.focus();
}

function updateCalendar(){const element=document.querySelector('#calendar');if(element){element.innerHTML=calendarHTML();syncCalendarTitles(element);}}
async function toggleCreator(){
 if(creatorTransition)return;
 const panel=document.querySelector('#creator-panel');
 if(creatorOpen&&panel&&!matchMedia('(prefers-reduced-motion: reduce)').matches&&typeof panel.animate==='function'){
   creatorTransition=true;const styles=getComputedStyle(panel),x=styles.getPropertyValue('--creator-shift-x').trim()||'24px',y=styles.getPropertyValue('--creator-shift-y').trim()||'0px';
   const animation=panel.animate([{opacity:1,transform:'translate(0,0)'},{opacity:0,transform:`translate(${x},${y})`}],{duration:180,easing:'ease-in',fill:'forwards'});
   try{await animation.finished;}catch{}finally{creatorTransition=false;}
   if(!panel.isConnected||route!=='course-list')return;
 }
 creatorOpen=!creatorOpen;creatorMotion=creatorOpen;persistCreator();render();if(creatorOpen&&matchMedia('(max-width:1799px)').matches){const panel=document.querySelector('#creator-panel');panel?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});panel?.focus({preventScroll:true});}
}
listenForDataReset(()=>{
 dataEpoch++;dismissCache(false);closeTransientDialogs();records=[];feed=undefined;progress={};demo=false;selected={};creator=[];creatorOpen=false;calendarItems=[];cacheExpanded=false;offerFilter={q:'',section:'',days:[]};render();
 // Settings remains open to display the deletion result; stale record dialogs close.
 const dialog=document.querySelector('#modal');if(dialog?.open&&!dialog.querySelector('#delete-result')){void closeModal({immediate:true}).then(()=>dialog.replaceChildren());}
});
root.addEventListener('click',async e=>{const a=e.target.closest('[data-action]'),block=e.target.closest('[data-course-info]'),event=e.target.closest('[data-event]');if(block){try{await showCourseInformation(block);}catch(error){toast(error.message);}return;}if(event){const item=calendarItems.find(x=>x.id===event.dataset.event);if(item){const details=calendarEventDialog(item);openModal(item.title,details.body,undefined,{footer:details.footer});}return;}
 if(!a){const link=e.target.closest('#side-menu a');if(link){if(link.getAttribute('href')?.startsWith('#')){e.preventDefault();const destination=link.getAttribute('href');await setMenu(false);location.hash=destination;}else void setMenu(false);}return;}try{switch(a.dataset.action){case 'dismiss-cache':dismissCache(true);render();break;case 'settings':if(menuOpen)await setMenu(false);openSettings();break;case 'menu':void setMenu(!menuOpen);break;case 'menu-close':setMenu(false);break;case 'profile-menu':case 'enrollment-menu':case 'current-menu':{const p=a.closest('.dropdown'),open=!p.classList.contains('open');p.classList.toggle('open',open);a.setAttribute('aria-expanded',String(open));break;}case 'exit':window.close();setTimeout(()=>toast('You can close this browser window to exit Better SOLAR.'),100);break;case 'scrape':case 'retry':if(demo){toast('Leave demo to collect your own records.');break;}dismissCache(false);await send(a.dataset.action==='retry'?'RETRY':'START');if(isExtension){progress=(await chrome.storage.local.get('scrapeProgress')).scrapeProgress||{};render();}break;case 'demo':demo=true;records=demoRecords();feed=demoFeed();progress={};viewDate=new Date(2026,10,1);selected={};render();toast('Synthetic demonstration loaded.');break;case 'leave-demo':demo=false;selected={};creator=[];persistCreator();await load();render();break;case 'connect':connectModal();break;case 'prev-month':viewDate=new Date(viewDate.getFullYear(),viewDate.getMonth()-1,1);updateCalendar();break;case 'next-month':viewDate=new Date(viewDate.getFullYear(),viewDate.getMonth()+1,1);updateCalendar();break;case 'today':viewDate=new Date();updateCalendar();break;case 'creator':await toggleCreator();break;case 'add-course':addCoursesModal();break;case 'add-block':addBlockModal();break;}}catch(error){toast(error.message);}});
// Delegated shade handler survives full navigation renders.
document.addEventListener('click',e=>{if(e.target.id==='menu-shade')setMenu(false);if(!e.target.closest('.dropdown'))document.querySelectorAll('.dropdown.open').forEach(p=>{p.classList.remove('open');p.querySelector('button')?.setAttribute('aria-expanded','false');});});
document.addEventListener('keydown',e=>{const block=e.target.closest?.('[role="button"][data-course-info]');if(block&&(e.key==='Enter'||e.key===' ')){e.preventDefault();block.click();return;}if(e.key==='Escape'){document.querySelectorAll('.dropdown.open').forEach(p=>p.classList.remove('open'));if(!document.querySelector('#side-menu')?.hidden)setMenu(false);}if(e.key==='Tab'&&!document.querySelector('#side-menu')?.hidden){const focusable=[...document.querySelectorAll('#side-menu a,#side-menu button')];const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
addEventListener('scroll',()=>{if(!scrollFrame)scrollFrame=requestAnimationFrame(()=>{scrollFrame=0;updateHeader();});},{passive:true});
addEventListener('hashchange',()=>{menuOpen=false;document.body.style.overflow='';render({motion:'page'});scrollTo({top:0});document.querySelector('h1')?.setAttribute('tabindex','-1');document.querySelector('h1')?.focus({preventScroll:true});});
addEventListener('online',()=>render());addEventListener('offline',()=>render());
async function load(){const epoch=dataEpoch,nextRecords=await allRecords(),nextFeed=await cachedFeed(),nextProgress=isExtension?(await chrome.storage.local.get('scrapeProgress')).scrapeProgress||{}:{};if(epoch!==dataEpoch)return;records=nextRecords;feed=nextFeed;progress=nextProgress;}
root.innerHTML=`<main class="app-main" aria-busy="true"><div class="skeleton"></div><div class="skeleton"></div><p>Loading your local academic records…</p></main>`;
await initTheme();await initializeExternalLinks();
void initializeFonts().then(()=>{syncSchedules();syncCalendarTitles();syncTablePeeks();});
try{await load();sessionStorage.removeItem('creator');render({motion:'launch'});}catch(error){root.innerHTML=`<main class="app-main"><h1>Local records could not be opened.</h1><p>${esc(error.message)}</p><p>Check available device storage and reload the extension.</p></main>`;}
if(isExtension){void chrome.runtime.sendMessage({type:'PROGRESS'}).catch(()=>{});}
if(isExtension)watchProgress(async(changes,area)=>{if(area==='local'&&changes.scrapeProgress&&!demo){const epoch=dataEpoch,nextRecords=await allRecords();if(epoch!==dataEpoch)return;if(progress.state!=='running'&&changes.scrapeProgress.newValue?.state==='running')dismissCache(false);progress=changes.scrapeProgress.newValue||{};records=nextRecords;render();}});
